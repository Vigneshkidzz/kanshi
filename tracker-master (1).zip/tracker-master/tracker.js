var app=angular.module('myDemo',['ui.router','ngStorage']);

