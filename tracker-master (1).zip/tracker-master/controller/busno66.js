app.controller('busno66',['$scope','$interval','$http',function($scope,$interval,$http){

    $interval(function() {
        $scope.loadmaps();
    }, 1000);
    $scope.loadmaps = function(){
       $.getJSON("https://api.thingspeak.com/channels/395198/fields/1/last.json?api_key=JGYUPTTJHV0SA9BV", function(result){
        
        $scope.m = result;
        console.log($scope.m);
        $scope.x=Number($scope.m.field1);
    });

    $.getJSON("https://api.thingspeak.com/channels/395198/fields/2/last.json?api_key=JGYUPTTJHV0SA9BV", function(result){
        
        $scope.n = result;
        console.log($scope.n);
        $scope.y=Number($scope.n.field2);
    });

        
        $scope.initialize();

    }
   
 $scope.initialize = function() {
      //alert(y);
   
    var mapOptions = {
        zoom: 14,
        center:{lat: $scope.x, lng: $scope.y},
        mapTypeId: google.maps.MapTypeId.TERRAIN
    }
    var myLatLng = {lat: $scope.x, lng: $scope.y};
    $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);

    var marker = new google.maps.Marker({
      position: {lat: $scope.x, lng: $scope.y},
      map: map
    });

    var marker = new google.maps.Marker({
        position: myLatLng,
        map: $scope.map,
        title: 'K S Rangasamy College of Technology,Tiruchengodu'
      });

   
  }


      $scope.busnumber={
        searchBus:undefined
      }


      $scope.searchBus = function(){
        $scope.busnumber=$scope.busnumber.searchBus;
        if($scope.busnumber == 66){
            $state.go('busno66');
        }
      }



     
 
}]);