app.controller('defaultloc',['$scope','$state', function($scope,$state) {
  
    var mapOptions = {
        zoom: 14,
        center: new google.maps.LatLng(11.3632, 77.8282),
        mapTypeId: google.maps.MapTypeId.TERRAIN
    }

    var myLatLng = {lat: 11.3632, lng: 77.8282};
    $scope.map = new google.maps.Map(document.getElementById('map'), mapOptions);

    var marker = new google.maps.Marker({
        position: myLatLng,
        map: $scope.map,
        title: 'K S Rangasamy College of Technology,Tiruchengodu'
      });


      $scope.busnumber={
        searchBus:undefined
      }


      $scope.searchBus = function(){
        $scope.busnumber=$scope.busnumber.searchBus;
        if($scope.busnumber == 66){
            $state.go('busno66');
        }
      }

}]);
    
    