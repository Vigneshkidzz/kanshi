app.controller('home', ['$scope', function($scope){
	
}]);