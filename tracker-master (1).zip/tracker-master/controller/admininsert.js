app.controller('admininsert',['$scope',function($scope){
		
	
}]);