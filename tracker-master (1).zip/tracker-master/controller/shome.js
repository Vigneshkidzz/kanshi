app.controller('shome',['$scope',function($scope){
	
	


}]);